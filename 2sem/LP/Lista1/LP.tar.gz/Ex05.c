/*
Exercício: Crie   um algoritmo e um programa em C que leia a 
medida dos três lados de um triângulo e determine se o triângulo é 
equilátero, isósceles ou escaleno, imprimindo o resultado na tela. 
*/

// todos os lados iguais = equilatero
// dois lados iguais pelo menos = isosleces
// todos diferentes = escaleno
