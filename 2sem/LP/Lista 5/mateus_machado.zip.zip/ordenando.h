void ShellSort(char *vetor, int tam);
void SelectionSort(char *vetor, int tam);
void BubbleSort(char *vet, int t);
void InsertionSort(char *v, int n);
